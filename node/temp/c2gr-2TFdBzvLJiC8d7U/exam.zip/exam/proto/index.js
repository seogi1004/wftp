/**
 * 본 코드에서 보여지는 자바스크립트의 주요 특성
 * 이해를 돕기 위해 주석에는 주로 OOP 용어를 사용함
 * 
 * 1. self invoking FE를 활용한 캡슐화 구현
 * 2. prototype 기반의 메소드 추가
 * 3. prototype 기반의 상속 구현
 * 4. prototype 체인 (print 메소드 참고)
 */

(function(global) {
"use strict";

/**
 * 자바스크립트 최상위 클래스인 Object의 메소드 추가
 * 모든 클래스의 객체는 print 메소드가 존재함
 */
Object.prototype.print = function(msg) {
	var body = document.getElementsByTagName("body")[0];
	body.innerHTML += msg + "<br/>";
}

/**
 * 유닛을 구현하기 위한 부모 클래스
 * 유닛에 대한 기본적인 메소드 정의
 */
function Unit() {
	this.attack = function(unit) {
		unit.attacked(this);
		this.print("'" + this.name + "' -> '" + unit.name + "' 공격");
	}

	this.attacked = function(unit) {
		this.hp -= unit.power;
	}
	
	this.showHP = function() {
		if(this.hp <= 0) 
			this.print("'" + this.name + "' 전투불능 상태");
		else 
			this.print("'" + this.name + "' HP " + this.hp);
	}
}

/**
 * 바이오닉 유닛을 구현하기 위한 자식 클래스
 * 바이오닉 유닛에 대한 기본 속성 정의
 */
function BionicUnit(name) {
	this.name = name;
	this.hp = 50;
	this.power = 10;
}

/**
 * 메카닉 유닛을 구현하기 위한 자식 클래스
 * 메카닉 유닛에 대한 기본 속성과 메소드 정의
 */
function MechanicUnit(name) {
	this.name = name;
	this.hp = 100;
	this.power = 50;

	this.repair = function(hp) {
		this.hp += hp;
	}
	
	// prototype 체인에 의해 Object.prototype.print 메소드는 무시됨
	this.print = function(msg) {
		var body = document.getElementsByTagName("body")[0];
		body.innerHTML += "<font style='color: red'>" + msg + "</font><br/>";
	}
}

// Unit 클래스 상속
BionicUnit.prototype = new Unit;
MechanicUnit.prototype = new Unit;

// 공개 인터페이스 설정 (Unit 클래스는 비공개)
global.Bionic = BionicUnit;
global.Mechanic = MechanicUnit;
	
})(window);