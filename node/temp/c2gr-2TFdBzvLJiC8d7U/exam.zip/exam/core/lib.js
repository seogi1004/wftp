/**
 * jQuery의 객체 생성 모델이 기본 컨셉
 * 
 * 1. jHelper.fn을 통해 외부에서 기능 확장이 가능함
 * 2. 셀렉터는 jHelper와 독립적으로 동작함
 */

(function(global) {
"use strict";
 
var jEventProxy = function(e) {
	var crossEvent = e ? e : global.event;
		
	if(!crossEvent.stopPropagation) {
		crossEvent.stopPropagation = function() {
			crossEvent.cancelBubble = true;
		}
	}
	
	if(!crossEvent.preventDefault) {
		crossEvent.preventDefault = function() {
			crossEvent.returnValue = false;
		}
	}
	
	crossEvent.target = (!crossEvent.target) ? crossEvent.srcElement : crossEvent.target;
	crossEvent.currentTarget = (!crossEvent.currentTarget) ? crossEvent.srcElement : crossEvent.currentTarget;
	
	jEventProxy.callback(crossEvent);
}

var jHelper = function(selector) {
	var items = __(selector);
	return new jHelper.fn.init(items);
}

/**
 * DOM Core API
 * 
 */
jHelper.fn = jHelper.prototype = {
	construnctor: jHelper,
	
	init: function(items) {
		this.items = items;
		this.length = items.length;
		
		return this;
	},
	
	each: function(callback) {
		for(var i=0, len=this.length; i < len; i++) {
			callback.call(this.items[i], i);
		}
		
		return this;
	},
	
	get: function(index) {
		return this.items[index];
	},
	
	size: function() {
		return this.length;
	}
}

/**
 * DOM Manipulation API
 * 
 */
jHelper.fn.appendTo = function(obj) {
	if(this.length == 1) {
		var elem = this.get(0),
			target = (obj.length == 1) ? obj.get(0) : jHelper(obj).get(0),
			parent = target.parentNode;
		
		parent.insertBefore(elem, target.nextSibling);
	}
	
	return this;
}

jHelper.fn.prependTo = function(obj) {
	if(this.length == 1) {
		var elem = this.get(0),
			target = (obj.length == 1) ? obj.get(0) : jHelper(obj).get(0),
			parent = target.parentNode;
			
		parent.insertBefore(elem, target);
	}
	
	return this;
}

jHelper.fn.append = function(obj) {
	this.each(function(i) {
		if(typeof obj == "string") { 
			this.innerHTML += obj;
		} else if(obj.nodeType) {
			this.appendChild(obj);
		}
	});
	
	return this;
}

jHelper.fn.prepend = function(obj) {
	this.each(function(i) {
		if(typeof obj == "string") { 
			this.innerHTML = obj + this.innerHTML;
		} else if(obj.nodeType) {
			this.insertBefore(obj, this.childNodes[0]);
		}
	}); 
	
	return this;
}

jHelper.fn.create = function(obj) {
	if(typeof obj == "object" && obj.tag) {
		this.each(function(i) {
			var elem = document.createElement(obj.tag);
			elem.textContent = (obj.html != "") ? obj.html : "";
			
			// attr, css 설정
			jHelper(elem).css(obj.css).attr(obj.attr);
			
			if(!obj.pos || obj.pos == "next") {
				jHelper(this).append(elem);
			} else if(obj.pos == "prev") {
				jHelper(this).prepend(elem);
			}
		});
	}
	
	return this;
}

jHelper.fn.html = function() {
	var args = arguments;
	
	if(this.items.length == 1 && args.length == 0)  {
		return this.items[0].innerHTML;
	} else {
		this.each(function(i) {
			if(args.length == 1 && typeof args[0] == "string") {
				this.innerHTML = args[0];
			}
		});
		 
		return this;
	}
	
	return "";
}

jHelper.fn.val = function() {
	var args = arguments;
	
	if(this.length == 1 && args.length == 0)  {
		return this.items[0].value;
	} else  {
		this.each(function(i) {
			if(args.length == 1 && typeof args[0] == "string") {
				this.value = args[0];
			}
		});
		 
		return this;
	}
	
	return "";
}

jHelper.fn.css = function() {
	var args = arguments;
	
	this.each(function(i) {
		if(args.length == 1 && typeof args[0] == "object") { 
			for(var key in args[0]) {
				this.style[key] = args[0][key];
			}
		} else if(args.length == 2 && typeof args[0] == "string") {
			this.style[args[0]] = args[1];
		}
	});
	
	return this;
}

jHelper.fn.attr = function() {
	var args = arguments;
	
	this.each(function(i) {
		if(args.length == 1 && typeof args[0] == "object") { 
			for(var key in args[0]) {
				this.setAttribute(key, args[0][key]);
			}
		} else if(args.length == 2 && typeof args[0] == "string") {
			this.setAttribute(args[0], args[1]);
		}
	});
	
	return this;
}

jHelper.fn.show = function() {
	this.each(function(i) {
		this.style.display = "";
	});
	
	return this;
}

jHelper.fn.hide = function() {
	this.each(function(i) {
		this.style.display = "none";
	});
	
	return this;
}

jHelper.fn.remove = function() {
	this.each(function(i) {
		this.parentNode.removeChild(this);
	});
	
	return this;
}

/**
 * DOM Event API
 * 
 */
jHelper.fn.bind = function(eventType, callback) {
	if(typeof eventType == "string" && typeof callback == "function") {
		jEventProxy.callback = callback;
		
		this.each(function(i) {
			(function(target, type) {
				if(target.addEventListener) {
					target.addEventListener(type, jEventProxy, false);
				} else if(target.attachEvent) {
					target.attachEvent( "on" + type, jEventProxy);
				}
			})(this, eventType.toLowerCase());
		});
	}
	
	return this;
}

jHelper.fn.unbind = function(eventType) {
	if(typeof eventType == "string") {
		this.each(function(i) {
			(function(target, type) {
				if(target.detachEvent) {
					target.detachEvent("on" + type, jEventProxy);
				} else {
					target.removeEventListener(type, jEventProxy);
				}
			})(this, eventType.toLowerCase());
		});
	}
	
	return this;
}

jHelper.fn.init.prototype = jHelper.fn;

// 공개 인터페이스 설정
global.jHelper = global.$$ = jHelper;

})(window);