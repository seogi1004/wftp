/**
 * DOM 엘리먼트를 가져올 수 있는 심플 셀렉터
 * 사용 방법은 jQuery 셀렉터와 비슷하며 구현된 문법은 아래와 같음
 * 
 * 1. __("E") 		- 태그 명이 E인 모든 엘리먼트
 * 2. __("#I") 		- 아이디가 I인 태그 명이 E인 엘리먼트
 * 3. __(".C")		- 클래스가 C인 모든 엘리먼트
 * 4. __("[A=V]")	- 값이 V인 에트리뷰트 A를 가지는 엘리먼트
 * 5. __("#I,.C,E") - ',' 콤마로 구분하여 셀렉터 조합이 가능함
 */

(function(global) {
"use strict";

var jParser = function(list, element, attrname, attrvalue) {
	var isAttr = function(attr, name) {
		for(var i=0, len=attr.length; i < len; i++) {
			if(attr[i].name == attrname) {
				if(attrname == "class") {
					if(attr[i].value.indexOf(attrvalue) != -1) 
						return true;
				} else {
					if(attr[i].value == attrvalue) 
						return true;
				}
			}
		}
		
		return false;
	}
	
	for(var i=0, len=element.children.length; i < len; i++) {
		var elem = element.children[i];
		
		if(isAttr(elem.attributes, name)) {
			list.push(elem);
		}
		
		if(elem.children.length > 0) {
			jParser(list, elem, attrname, attrvalue);
		}
	}
	
	return list;
}

var jSelectorNode = function(selector) {
	var selList = [];
	var regexp = /^[A-Za-z1-6]{1,10}/gi,
		regexp_attr = /\[[A-Za-z]*=[A-Za-z0-9\-\_]*\]/gi;
	
	if(typeof selector === "string") {
		selector = selector.toLowerCase();
		
		if(regexp.test(selector)) {
			var elemList = document.getElementsByTagName(selector);
			
			for(var i=0, len=elemList.length; i < len; i++) {
				selList.push(elemList[i]);
			}
		} else {
			var body = document.getElementsByTagName("body")[0];
			
			if(regexp_attr.test(selector)) {
				selector = selector.substring(1, selector.length - 1);
				
				var tmpSel = selector.split("=");
				selList = selList.concat(jParser([], body, tmpSel[0], tmpSel[1]));
			} else {
				var code = selector.charAt(0),
					selector = selector.substring(1);
				
				if(code == "#") {
					var elem = document.getElementById(selector);
					
					if(elem && elem.nodeType) {
						selList.push(elem);
					}
				} else if(code == ".") {
					selList = selList.concat(jParser([], body, "class", selector));
				}
			}
		}
	} else if(selector.nodeType) {
		selList.push(selector);
	} else {
		if(selector.length && selector[0].nodeType) {
			selList = selList.concat(selector);
		} else {
			if(selector == window || selector == document) {
				selList.push(selector);
			}
		}
	}
	
	return selList;
}

var jSelector = function(selector) {
	if(typeof selector == "string" && selector.indexOf(",") != -1) {
		var selListGroup = [],
			tmpSelList = selector.split(",");
		
		for(var i=0, len=tmpSelList.length; i < len; i++) {
			var tmpSel = tmpSelList[i];
			
			if(tmpSel != "") {
				selListGroup = selListGroup.concat(jSelectorNode(tmpSel));
			}
		}
		
		return selListGroup;
	} else {
		return jSelectorNode(selector);
	}
}

// 공개 인터페이스 설정
global.jSelector = global.__ = jSelector;

})(window);